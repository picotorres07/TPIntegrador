#!/bin/bash

#script para backup full del TP grupal

ORIGEN=$1
DESTINO=$2
FECHA=$(date +%Y%m%d)

# Mostrar ayuda
if [[ "$1" == "-h" || "$1" == "-help" ]]; then
    echo "Uso: $0 <origen> <destino>"
    echo
    echo "Este script crea un archivo comprimido .tar.gz del directorio de origen en el destino especificado."
    echo
    echo "Parámetros:"
    echo "  origen   Ruta del directorio a realizar el backup"
    echo "  destino  Ruta donde se guardará el archivo de backup"
    echo
    echo "Ejemplo:"
    echo "  $0 /var/log /backup_dir"
    echo
    echo "La salida sera:"
    echo "  log_bkp_2025-11-07.tar.gz"
    exit 0
fi

# verificamos que existan los archivos y directorios a hacer el bck
if [[ -d "$ORIGEN" ]]; then

	tar -czf "$DESTINO/$(basename $ORIGEN)_bkp_$FECHA.tar.gz" "$ORIGEN"
	
else 
	echo "No existe el directorio $ORIGEN"

fi
